# winter-school-2023
This repository contains the material of the Tinker Winter-School of the 10th of february 2023
